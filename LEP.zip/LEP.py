import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from flask import Flask, render_template, request

# 1. Train model
df = pd.read_csv('loan_dataset.csv')
X = df.drop(' loan_status', axis=1)
y = df[' loan_status']

categorical_features = X.select_dtypes(include=['object']).columns
numerical_features = X.select_dtypes(include=['int64', 'float64']).columns

preprocessor = ColumnTransformer([
    ('num', StandardScaler(), numerical_features),
    ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features)
], remainder='passthrough')

pipeline = Pipeline([
    ('preprocessor', preprocessor),
    ('classifier', RandomForestClassifier(random_state=42))
])

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
param_grid = {
    'classifier__n_estimators': [100, 200, 500],
    'classifier__max_depth': [None, 10, 20, 30]
}
grid_search = GridSearchCV(
    estimator=pipeline,
    param_grid=param_grid,
    cv=5,
    scoring='accuracy',
    n_jobs=-1
)
grid_search.fit(X_train, y_train)
best_pipeline = grid_search.best_estimator_

# 2. Flask app
app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    prediction = None
    if request.method == 'POST':
        data = request.form
        input_data = {
            'loan_id': int(data.get('loan_id')),
            ' no_of_dependents': int(data.get('dependents')),
            ' education': data.get('education'),
            ' self_employed': data.get('self_employed'),
            ' income_annum': int(data.get('annual_income')),
            ' loan_amount': int(data.get('loan_amount')),
            ' loan_term': int(data.get('loan_term')),
            ' cibil_score': int(data.get('cibil_score')),
            ' residential_assets_value': int(data.get('residential_assets')),
            ' commercial_assets_value': int(data.get('commercial_assets')),
            ' luxury_assets_value': int(data.get('luxury_assets')),
            ' bank_asset_value': int(data.get('bank_assets'))
        }
        user_df = pd.DataFrame([input_data])
        pred = best_pipeline.predict(user_df)
        prediction = pred[0]
    return render_template('home.html', prediction=prediction)

if __name__ == '__main__':
    app.run(debug=True)
